import React from 'react'
import styles from './style.module.scss'
import useKeydownSelector from 'utils/useKeydownSelector'
import BrdInputSuggestion from 'components/BrdInputSuggestion'

export default ({ suggestions = [], handleSelectSuggestion = () => {} }) => {
  const { selectedIndex } = useKeydownSelector(suggestions, handleSelectSuggestion)
  return (
    <div 
      className={styles['BrdInputSuggestionList']} 
      tabIndex="0"
    >
    {
      suggestions.map((suggestion, index) => {
        return (
          <BrdInputSuggestion 
            tabIndex="-1"
            active={ index === selectedIndex }
            key={`suggestion-${suggestion}`}
            handleSelectSuggestion={ () => { handleSelectSuggestion(suggestion) } }
          >{suggestion}</BrdInputSuggestion>
        )
      })
    }
    </div>
  )
}