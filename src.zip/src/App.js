import React from 'react';
import { Switch, Route } from 'react-router'
import BrdBoardView from 'containers/BrdBoardView'
import { setModalMap, useCloseAllModal } from 'modules/modal'

const modalMap = [
  { 
    id: 'BrdFormModal',
    children: [
      {
        id: 'BrdLabelModal',
        children: []
      }
    ]
  }
]

let modals = setModalMap(modalMap)
console.log(modals)

function App() {
  const closeAllModal = useCloseAllModal()
  window.addEventListener('click', closeAllModal)

  return (
    <Switch>
      <Route path="/" component={BrdBoardView} />
    </Switch>
  );
}

export default App;