import { useState, useEffect } from 'react'
import createKeyHandler from 'utils/createKeyHandler'

export default (list, handleSelect = () => {}) => {
  const [selectedIndex, setSelectedIndex] = useState(-1)
  const length = list.length

  const incSelectedIndex = () => {
    if (length === 0) return
    const index = selectedIndex + 1 >= length ? -1 : selectedIndex + 1
    setSelectedIndex(index)
  }

  const decSelectedIndex = () => {
    if (length === 0) return
    const index = selectedIndex - 1 < 0 ? -1 : selectedIndex - 1
    setSelectedIndex(index)
  }

  useEffect(() => {
    const onKeydown = createKeyHandler({
      'Up': decSelectedIndex,
      'Down': incSelectedIndex,
      'Enter': (e) => {
        handleSelect(list[selectedIndex])
        e.target.blur()
      }
    })
    window.addEventListener('keydown', onKeydown)
    return () => {
      window.removeEventListener('keydown', onKeydown)
    }
  })
  
  useEffect(() => {
    setSelectedIndex(-1)
  }, [])

  return {
    selectedIndex,
    setSelectedIndex
  }
}

