import { useSelector } from 'react-redux'

export const useColorList = () => {
  const colorList = useSelector(state => state.colorList.colorList)
  return [colorList]
}
