export const TEXT = 'TEXT'
export const LABEL = 'LABEL'
