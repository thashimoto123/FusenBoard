import React from 'react'
import cn from 'classnames/bind'
import styles from './style.module.scss'
import { useModal } from 'modules/modal'

const cx = cn.bind(styles)

export default ({ color = 'white', children, className = '', onClick = () => {}, modalId = 0 }) => {
  const classname = cn(
    className, 
    cx('BrdModal')
  )
  const { onClickModal } = useModal(modalId)
  return (
    <div className={classname} style={{ backgroundColor: color }} onClick={(e) => {onClick(e); onClickModal(e)}} >
      { children }
    </div>
  )
}