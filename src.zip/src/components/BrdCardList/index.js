import React from 'react'
import BrdCard from 'components/BrdCard'
import styles from './style.module.scss'

export default ({handleClickCard = () => {}, cardList = []}) => {
  return (
    <ul className={styles['cardList']}>
    {cardList.map((card) => {
      return <BrdCard key={`card-${card.id}`} text={card.text} color={card.color} onClick={ handleClickCard(card) } /> 
    })}
    </ul>
  )
}