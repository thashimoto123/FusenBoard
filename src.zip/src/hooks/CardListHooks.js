import * as act from 'actions/CardListActions'
import * as Sort from 'constants/SortTypes'
import * as Order from 'constants/OrderTypes'
import { useSelector, useDispatch } from 'react-redux'

export const useCardList = () => {
  const dispatch = useDispatch()
  const [sort] = useCardSort()
  const [order] = useCardOrder()
  const cardList = useSelector(state => state.cardList.cardList)
  switch (sort) {
    case Sort.TEXT:
      cardList.sort((a, b) => {
        let A = a.text.toUpperCase()
        let B = b.text.toUpperCase()
        if (order === Order.DESC) {
          A = b.text.toUpperCase()
          B = a.text.toUpperCase()
        }
        if (A < B) return -1
        if (A > B) return 1
        return 0
      })
      break
    case /^LABEL_.*/:
      const id = sort.replace('LABEL_', '')
      cardList.sort((a, b) => {
        let labelA = a.labels.find(label => label.id === id)
        let labelB = b.labels.find(label => label.id === id)
        if (order === Order.DESC) {
          labelA = b.labels.find(label => label.id === id)
          labelB = a.labels.find(label => label.id === id)
        }
        if (!labelB || !labelB.value) return -1
        if (!labelA || !labelA.value) return 1
        if (labelA.value < labelB.value) return -1
        if (labelA.value > labelB.value) return 1
        return 0
      })
      break
    default: cardList.sort()
  }
  const updateCardList = (cardList) => {
    dispatch(act.updateCardList(cardList))
  }
  return [cardList, updateCardList]
}

export const useCard = (id) => {
  const dispatch = useDispatch()
  const card = useSelector(state => state.cardList.cardList.find(card => card.id === id))
  const updateCard = (updateData) => {
    dispatch(act.updateCard({
      ...card,
      ...updateData
    }))
  }
  return [card, updateCard]
}

export const useAddCard = () => {
  const dispatch = useDispatch()
  const addCard = (card) => {
    dispatch(act.addCard(card))
  }
  return [addCard]
}

export const useUpdateCard = () => {
  const dispatch = useDispatch()
  const updateCard = (card) => {
    dispatch(act.updateCard(card))
  }
  return [updateCard]
}

export const useRemoveCard = () => {
  const dispatch = useDispatch()
  const removeCard = (id) => {
    dispatch(act.removeCard(id))
  }
  return [removeCard]
}

export const useAllCardLabelValues = (labelId) => {
  const cardList = useSelector(state => state.cardList.cardList)
  const values = []
  let value, label

  cardList.forEach(card => {
    label = card.labels.find(label => label.id === labelId )
    if (!label || !label.value) return
    value = label.value
    if (values.indexOf(value) === -1) values.push(value) 
  })
  return [values]
}

export const useUpdateCardSort = () => {
  const dispatch = useDispatch()
  const updateSortBy = (type) => {
    dispatch(act.updateSortBy(type))
  }
  return [updateSortBy]
}

export const useCardSort = () => {
  const sort = useSelector(state => state.cardList.sortBy)
  let type;
  switch (sort) {
    case Sort.TEXT:
      type = Sort.TEXT
      break
    case /^LABEL_.*/:
      type = Sort.LABEL
      break
    default:
      type = Sort.TEXT
  }
  const updateSortBy = useUpdateCardSort()
  return [sort, type, updateSortBy]
}

export const useUpdateCardOrder = () => {
  const dispatch = useDispatch()
  const updateOrderBy = (type) => {
    dispatch(act.updateOrderBy(type))
  }
  return [updateOrderBy]
}

export const useCardOrder = () => {
  const order = useSelector(state => state.cardList.orderBy)
  const updateOrderBy = useUpdateCardOrder()
  return [order, updateOrderBy]
}