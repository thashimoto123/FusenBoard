import * as Actions from 'constants/ActionTypes'
export const updateLabels = (labelList) => {
  return {
    type: Actions.UPDATE_LABELS,
    labelList
  }
}