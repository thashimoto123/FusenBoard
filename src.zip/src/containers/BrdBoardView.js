import React from 'react'
import BrdBoardView from 'components/BrdBoardView'
import { useCardList } from 'hooks/CardListHooks'
import { useUpdateCardForm } from 'hooks/CardFormHooks'
import { useModal, useOpenModal } from 'modules/modal'

export default () => {
  const [cardList] = useCardList()
  const openModal = useOpenModal()
  const [updateCardForm] = useUpdateCardForm()
  const handleClickCard = (card) => (e) => {
    e.stopPropagation()
    updateCardForm(card)
    openModal('BrdFormModal')
  }
  const { active: formModalActive } = useModal('BrdFormModal')
  const { active: labelsModalActive } = useModal('BrdLabelModal')
  return  (
    <BrdBoardView 
      cardList={cardList} 
      handleClickCard={handleClickCard}
      formModalActive={formModalActive}
      labelsModalActive={labelsModalActive}
    />
  )
}