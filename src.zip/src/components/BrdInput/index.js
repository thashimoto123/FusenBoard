import React from 'react'
import cn from 'classnames/bind'
import styles from './style.module.scss'

const cx = cn.bind(styles)

export default ({
  value = '',
  border = false,
  mini = '',
  className = '',
  basic,
  style = {},
  onChange = () => {}, 
  onFocus = () => {}, 
  onBlur = () => {},
}) => {
  const classname = cn(
    className,
    cx({
      BrdInput: true,
      mini,
      border,
      basic
    })
  )
  return (
    <input 
      type="text" 
      className={classname} 
      style={style}
      value={value} 
      onChange={onChange} 
      onFocus={onFocus}
      onBlur={onBlur}
    />
  )
}