import { useState } from 'react'
import shortid from 'shortid'
import { useLabelList, useUpdateLabels } from 'hooks/LabelListHooks'

export  const useLabels = () => {
  const [labelList] = useLabelList()
  const [updateLabels] = useUpdateLabels()
  const initialLabelsState =  labelList.map(label => {return {id: label.id, name: label.name, delete: false }})
  const [labels, setLabels] = useState(initialLabelsState)

  const setLabel = (id, name) => {
    const newLabels = [...labels]
    const label = newLabels.find(label => label.id === id)
    if (label) {
      label.name = name
    }
    setLabels(newLabels)
  }

  const addLabel = () => {
    const newLabels = [...labels]
    newLabels.unshift({
      id: shortid.generate(),
      name: '',
      delete: false
    })
    setLabels(newLabels)
  }

  const checkDeleteFlag = (id, value) => {
    const newLabels = [...labels]
    let label = newLabels.find(label => label.id === id)
    if (!label) return 
    label.delete = value
    setLabels(newLabels)
  }

  const saveLabels = () => {
    const newLabels = labels
      .filter(label => (label.name && !label.delete))
      .map(label => { return {id: label.id, name: label.name } })
    updateLabels(newLabels)
  }

  return {
    labels,
    setLabel,
    addLabel,
    checkDeleteFlag,
    saveLabels
  }
}