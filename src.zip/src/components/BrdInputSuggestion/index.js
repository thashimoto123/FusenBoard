import React from 'react'
import cn from 'classnames/bind'
import styles from './style.module.scss'
const cx = cn.bind(styles)

export default ({active, children, handleSelectSuggestion = () => {}}) => {
  const className = cx({
    BrdInputSuggestion: true,
    active: active
  })
  return (
    <div 
      tabIndex="-1"
      className={ className } 
      onMouseDown={ handleSelectSuggestion }
    >{children}</div>
  )
}