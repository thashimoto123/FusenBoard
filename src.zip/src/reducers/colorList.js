export const initialColorList = ['#f6ecbf', '#D7E7F8', '#F6C6E4'];
const initialState = {
  colorList: initialColorList
}

export default (state = initialState) => {
  return state
}