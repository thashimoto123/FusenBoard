import React from 'react'
import cn from 'classnames/bind'
import BrdButton from 'components/BrdButton'
import BrdSelect from 'components/BrdSelect'
import BrdInput from 'components/BrdInput'
import BrdInputSuggestionList from 'components/BrdInputSuggestionList'
import styles from './style.module.scss'
import { useOpenModal } from 'modules/modal'
import { useLabelList } from 'hooks/LabelListHooks'
import { useCardSort } from 'hooks/CardListHooks'
import { useFocus } from 'react-hooks-lib'
import { useInitializeCardForm } from 'hooks/CardFormHooks'
import * as Sort from 'constants/SortTypes'
import * as Order from 'constants/OrderTypes'
const cx = cn.bind(styles)

export default () => {
  const openModal = useOpenModal()
  const [initializeCardForm] = useInitializeCardForm()
  const [labelList] = useLabelList() 
  const handleClickAddButton = (e) => {
    e.stopPropagation()
    initializeCardForm()
    openModal('BrdFormModal')
  }
  const [sort, type] = useCardSort()
  const value = type === Sort.TEXT ? 'テキスト' : type === Sort.LABEL ? labelList.find(label => label.id === sort.replace('LABEL_', '')).name : ''
  const { focused, bind: bindFocus } = useFocus()

  return (
    <div className={cx('header')}>
      <BrdButton basic onClick={handleClickAddButton} ><i className="icon">&#xe802;</i></BrdButton>
      <BrdInput value={value} basic style={{width: 'auto'}} {...bindFocus} />
      { focused && <BrdInputSuggestionList />}
      <BrdSelect basic list={['a', 'b', 'c']} label='SORT_BY'>
        <option value={Sort.TEXT}>テキスト</option>
        <optgroup label="ラベル">
          {
            labelList.map(label => {
              return <option value={'LABEL_' + label.id} >{ label.name }</option>
            })
          }
        </optgroup>
      </BrdSelect>
      <BrdSelect basic list={['a', 'b', 'c']} label='ORDER_BY' />
    </div>
  )
}