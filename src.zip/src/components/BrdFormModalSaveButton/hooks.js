import { useSelector, useDispatch } from 'react-redux'
import { addCard, updateCard } from 'actions/CardListActions'
import { closeModal } from 'modules/modal'

export default () => {
  const dispatch = useDispatch()
  const formData = useSelector(state => state.card);

  return {
    onClick() {
      if (formData.id) {
        dispatch(updateCard(formData))
      } else {
        dispatch(addCard(formData))
      }
      dispatch(closeModal('BrdFormModal'))
    }
  }
}