import * as Actions from 'constants/ActionTypes'
import * as Sort from 'constants/SortTypes'
import * as Order from 'constants/OrderTypes'
import shortid from 'shortid'

const initialState = {
  cardList: [
  
  ],
  sortBy: Sort.TEXT,
  orderBy: Order.DESC
}

export default function(state = initialState, action) {
  switch(action.type) {
    case Actions.UPDATE_CARD_LIST:
      return {
        cardList: action.cardList
      }
      
    case Actions.ADD_CARD:
      return {
        ...state,
        cardList: [...state.cardList,
          {
            ...action.card,
            id: shortid.generate()
          }
        ]
      }
        
    case Actions.REMOVE_CARD:
      return (() => {
        const index = state.cardList.findIndex((card) => card.id === action.id)
        return {
          ...state,
          cardList: [...state.cardList].slice(index, 1)
        }
      })()

    case Actions.UPDATE_CARD:
      return (() => {
        const index = state.cardList.findIndex((card) => card.id === action.card.id)
        const cardList = [...state.cardList]
        cardList[index] = action.card
        return {
          ...state,
          cardList
        }
      })()

    case Actions.UPDATE_SORT_BY:
      return {
        ...state,
        sortBy: action.sortBy
      }

    case Actions.UPDATE_ORDER_BY:
      return {
        ...state,
        orderBy: action.orderBy
      }

    default: 
      return state
  }
}