import React from 'react'
import BrdHeader from 'components/BrdHeader'
import BrdCardList from 'components/BrdCardList'
import BrdFormModal from 'components/BrdFormModal'
import BrdLabelModal from 'components/BrdLabelModal'
import classes from './style.module.scss'

export default ({ cardList = [], handleClickCard = () => {}, formModalActive, labelsModalActive }) => {
  
  return (
    <div className={classes['BrdBoardView']}>
      <BrdHeader />      
      <BrdCardList cardList={cardList} handleClickCard={ handleClickCard } />
      { formModalActive && <BrdFormModal color={'#f6ecbf'} /> }
      { labelsModalActive && <BrdLabelModal />}
    </div>
  )
}